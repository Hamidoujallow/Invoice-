import React, { useState } from "react";
import jsPDF from "jspdf";
import "jspdf-autotable";

export default function App() {
  const [items, setItems] = useState([{ description: "", price: "" }]);
  const [customer, setCustomer] = useState("");

  const addItem = () => setItems([...items, { description: "", price: "" }]);

  const updateItem = (i, field, value) => {
    const newItems = [...items];
    newItems[i][field] = value;
    setItems(newItems);
  };

  const total = items.reduce((sum, item) => sum + Number(item.price || 0), 0);

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.text("Invoice", 14, 20);
    doc.text(`Customer: ${customer}`, 14, 30);
    doc.autoTable({
      startY: 40,
      head: [["Description", "Price"]],
      body: items.map(item => [item.description, item.price]),
    });
    doc.text(`Total: $${total}`, 14, doc.lastAutoTable.finalY + 10);
    doc.save("invoice.pdf");
  };

  const shareWhatsApp = () => {
    const message = `Invoice for ${customer}: Total $${total}`;
    window.open(`https://wa.me/?text=${encodeURIComponent(message)}`);
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Invoice App</h1>
      <input
        placeholder="Customer Name"
        value={customer}
        onChange={(e) => setCustomer(e.target.value)}
      />
      {items.map((item, i) => (
        <div key={i}>
          <input
            placeholder="Description"
            value={item.description}
            onChange={(e) => updateItem(i, "description", e.target.value)}
          />
          <input
            placeholder="Price"
            type="number"
            value={item.price}
            onChange={(e) => updateItem(i, "price", e.target.value)}
          />
        </div>
      ))}
      <button onClick={addItem}>Add Item</button>
      <h3>Total: ${total}</h3>
      <button onClick={generatePDF}>Save PDF</button>
      <button onClick={shareWhatsApp}>Share via WhatsApp</button>
    </div>
  );
}